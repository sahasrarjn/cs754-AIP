These images were created by downsampling very high resolution JPEGs from
Wikipedia. Most are available under a Creative Commons license, and all are
believed to be redistributable, however many require attribution. Please see
the page corresponding to each file for the required attribution and licensing
information.

https://commons.wikimedia.org/wiki/File%3A20100701_Pelpin%2C_cathedral%2C_1.jpg
https://commons.wikimedia.org/wiki/File%3A77_Bombay_Street_Photo_by_Sven_Fischer.jpg
https://commons.wikimedia.org/wiki/File%3A80_-_Machu_Picchu_-_Juin_2009_-_edit.2.jpg
https://commons.wikimedia.org/wiki/File%3AAbandoned_Railroad_Signal.jpg
https://commons.wikimedia.org/wiki/File%3AAbashiri_Station06s3.jpg
https://commons.wikimedia.org/wiki/File%3ABaruch.jpg
https://commons.wikimedia.org/wiki/File%3ABas_Relief_Cuverville03_hq.jpg
https://commons.wikimedia.org/wiki/File%3ABodhi_Baum%2C_Sri_Lanka.jpg
https://commons.wikimedia.org/wiki/File%3ABranaunmore06%28js%29.jpg
https://commons.wikimedia.org/wiki/File%3ABrei%C3%B0adalshei%C3%B0i_01.jpg
https://commons.wikimedia.org/wiki/File%3ACRAY-2_IMG_8974.CR2.jpg
https://commons.wikimedia.org/wiki/File%3ACamelo_-_Timanfaya_-_Lanzarote_-_Illas_Canarias-_Spain-T32.jpg
https://commons.wikimedia.org/wiki/File%3ACorona_Arch.jpg
https://commons.wikimedia.org/wiki/File%3ADompropstei_Hildesheim.jpg
https://commons.wikimedia.org/wiki/File%3ADublin_2010_St_Patricks_Day_Parade_-_Spraoi_by_infomatique.jpg
https://commons.wikimedia.org/wiki/File%3AErfurt_Dom_Domtreppe_Severikirche_at_night.jpg
https://commons.wikimedia.org/wiki/File%3AEuphagus_cyanocephalus_-Oakland%2C_California%2C_USA_-adult_male_with_chick-8c.jpg
https://commons.wikimedia.org/wiki/File%3AExercises_at_the_barre%2C_Prix_de_Lausanne_2010-2.jpg
https://commons.wikimedia.org/wiki/File%3AFontaine_-_Place_Stanislas_-_Nancy_-_P1300523-P1300532.jpg
https://commons.wikimedia.org/wiki/File%3AFragata_ARA_Libertad_%28Q-2%29_%283645511700%29.jpg
https://commons.wikimedia.org/wiki/File%3AHead_Phones_President_20110225_Japan_Expo_Sud_22.jpg
https://commons.wikimedia.org/wiki/File%3AIrishMannequinNOLAHighsmith.jpg
https://commons.wikimedia.org/wiki/File%3AIsle_Of_Skye_A863_The_Cuillins.jpg
https://commons.wikimedia.org/wiki/File%3AJacquelineMegaw.jpg
https://commons.wikimedia.org/wiki/File%3AKITT_Interior_at_Toronto_Auto_Show_2011.jpg
https://commons.wikimedia.org/wiki/File%3AKoln-Night-GavinCato.jpg
https://commons.wikimedia.org/wiki/File%3AKunts_04.jpg
https://commons.wikimedia.org/wiki/File%3ALa_Tomatina_%2825.08.2010%29_-_Spain%2C_Bu%C3%B1ol_21.jpg
https://commons.wikimedia.org/wiki/File%3ALinz-cathedrale.jpg
https://commons.wikimedia.org/wiki/File%3ALoewe_von_aspern2.jpg
https://commons.wikimedia.org/wiki/File%3AMagicKindom-highres-park-cc.jpg
https://commons.wikimedia.org/wiki/File%3AMichigan_Stadium_2011.jpg
https://commons.wikimedia.org/wiki/File%3ANan_Lian_Garden_7645432.jpg
https://commons.wikimedia.org/wiki/File%3ANovafjellet%2C_2009_09.JPG
https://commons.wikimedia.org/wiki/File%3AOrion_Nebula_%28M42%29_part_HST_4800px.%2A
https://commons.wikimedia.org/wiki/File%3AOtaria_flavescens_-_Rancho_Texas_Park_-_T%C3%ADas_-_Lanzarote_-PC31.jpg
https://commons.wikimedia.org/wiki/File%3APanorama_von_Monaco-La_Turbie.jpg
https://commons.wikimedia.org/wiki/File%3APlace_Stanislas_-_Lumi%C3%A8re.jpg
https://commons.wikimedia.org/wiki/File%3APolished_slice_of_petrified_wood_%28Large_Image%29.jpg
https://commons.wikimedia.org/wiki/File%3APorto_deportivo_de_Vilagarc%C3%ADa_de_Arousa._Galiza-V24.jpg
https://commons.wikimedia.org/wiki/File%3ARed_Bull_Jungfrau_Stafette%2C_10th_stage_-_vintage_cars_%282%29.jpg
https://commons.wikimedia.org/wiki/File%3ARicardo_Quaresma_%28L%29%2C_Pablo_Zabaleta_%28R%29_%E2%80%93_Portugal_vs._Argentina%2C_9th_February_2011.jpg
https://commons.wikimedia.org/wiki/File%3ARoad_to_%C3%85rstein%2C_2010_September.JPG
https://commons.wikimedia.org/wiki/File%3ASaint_Catherine-Caravaggio_%281598%29.jpg
https://commons.wikimedia.org/wiki/File%3AStreptopelia_orientalis_-Japan-8.jpg
https://commons.wikimedia.org/wiki/File%3AThomas_Bresson_-_Fort_de_Roppe_%28abri-caverne%29.jpg
https://commons.wikimedia.org/wiki/File%3AUn_known_type_crawler_%281%29.jpg
https://commons.wikimedia.org/wiki/File%3AVocabulaire_de_l%27acad%C3%A9mie%2C_1832_01.jpg
https://commons.wikimedia.org/wiki/File%3AZoo_de_la_Barben_20100605_048.jpg
https://commons.wikimedia.org/wiki/File%3A%D0%92%D0%B8%D0%B4_%D0%B8%D0%B7_Green_Plaza_065.jpg
